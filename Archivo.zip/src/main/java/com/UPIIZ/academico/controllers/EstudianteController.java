package com.UPIIZ.academico.controllers;

import com.UPIIZ.academico.entities.Estudiante;
import com.UPIIZ.academico.services.EstudianteService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/estudiantes")
public class EstudianteController {

    private final EstudianteService service;

    public EstudianteController(EstudianteService service) {
        this.service = service;
    }

    // CREAR ESTUDIANTE
    @PostMapping
    public ResponseEntity<Estudiante> crear(@RequestBody Estudiante estudiante) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.crear(estudiante));
    }

    // LISTAR ESTUDIANTES
    @GetMapping
    public ResponseEntity<List<Estudiante>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    // OBTENER ESTUDIANTE POR DUI
    @GetMapping("/{dui}")
    public ResponseEntity<Estudiante> obtener(@PathVariable String dui) {
        return ResponseEntity.ok(service.obtenerPorDui(dui));
    }

    // ELIMINAR ESTUDIANTE
    @DeleteMapping("/{dui}")
    public ResponseEntity<Void> eliminar(@PathVariable String dui) {
        service.eliminar(dui);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{dui}/cursos/{codigoCurso}")
    public ResponseEntity<Void> inscribirCurso(
            @PathVariable String dui,
            @PathVariable String codigoCurso) {

        service.inscribirCurso(dui, codigoCurso);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}

