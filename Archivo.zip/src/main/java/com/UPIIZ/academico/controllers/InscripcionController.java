package com.UPIIZ.academico.controllers;

import com.UPIIZ.academico.entities.Curso;
import com.UPIIZ.academico.entities.Inscripcion;
import com.UPIIZ.academico.services.InscripcionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class InscripcionController {

    private final InscripcionService inscripcionService;

    public InscripcionController(InscripcionService inscripcionService) {
        this.inscripcionService = inscripcionService;
    }

    // INSCRIBIR estudiante en curso
    @PostMapping("/estudiantes/{dui}/cursos/{codigoCurso}")
    public ResponseEntity<Inscripcion> inscribir(
            @PathVariable String dui,
            @PathVariable String codigoCurso) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(inscripcionService.inscribir(dui, codigoCurso));
    }

    // LISTAR cursos de un estudiante
    @GetMapping("/estudiantes/{dui}/cursos")
    public ResponseEntity<List<Curso>> cursosDeEstudiante(
            @PathVariable String dui) {

        return ResponseEntity.ok(
                inscripcionService.cursosPorEstudiante(dui)
        );
    }
}



