package com.UPIIZ.academico.repositories;

import com.UPIIZ.academico.entities.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepository extends JpaRepository<Profesor, String> {}
