package com.UPIIZ.academico.services;

import com.UPIIZ.academico.entities.Profesor;
import com.UPIIZ.academico.repositories.ProfesorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProfesorService {

    private final ProfesorRepository repository;

    public ProfesorService(ProfesorRepository repository) {
        this.repository = repository;
    }

    public Profesor crear(Profesor profesor) {
        return repository.save(profesor);
    }

    public List<Profesor> listar() {
        return repository.findAll();
    }

    public Profesor obtenerPorCodigo(String codigo) {
        return repository.findById(codigo)
                .orElseThrow(() -> new RuntimeException("Profesor no encontrado"));
    }

    public void eliminar(String codigo) {
        repository.deleteById(codigo);
    }
}